This component extends the Neo4j JMX component with management support for
the Neo4j graph database.
For more information, see http://components.neo4j.org/neo4j-management/