The jar file is empty, this project is only intended
for dependency resolution using tools like Maven.

