/**
 */

package org.eclipse.gmt.modisco.java;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Abstract Method Declaration</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 * <li>{@link org.eclipse.gmt.modisco.java.AbstractMethodDeclaration#getBody <em>Body</em>}</li>
 * <li>{@link org.eclipse.gmt.modisco.java.AbstractMethodDeclaration#getParameters <em>Parameters</em>}</li>
 * <li>{@link org.eclipse.gmt.modisco.java.AbstractMethodDeclaration#getThrownExceptions <em>Thrown
 * Exceptions</em>}</li>
 * <li>{@link org.eclipse.gmt.modisco.java.AbstractMethodDeclaration#getTypeParameters <em>Type Parameters</em>}</li>
 * <li>{@link org.eclipse.gmt.modisco.java.AbstractMethodDeclaration#getUsagesInDocComments <em>Usages In Doc
 * Comments</em>}</li>
 * <li>{@link org.eclipse.gmt.modisco.java.AbstractMethodDeclaration#getUsages <em>Usages</em>}</li>
 * </ul>
 *
 * @model abstract="true"
 * @generated
 * @see org.eclipse.gmt.modisco.java.JavaPackage#getAbstractMethodDeclaration()
 */
public interface AbstractMethodDeclaration extends BodyDeclaration {

    /**
     * Returns the value of the '<em><b>Body</b></em>' containment reference.
     * <!-- begin-user-doc -->
     * <p>
     * If the meaning of the '<em>Body</em>' containment reference isn't clear,
     * there really should be more of a description here...
     * </p>
     * <!-- end-user-doc -->
     *
     * @return the value of the '<em>Body</em>' containment reference.
     *
     * @model containment="true" ordered="false"
     * @generated
     * @see #setBody(Block)
     * @see org.eclipse.gmt.modisco.java.JavaPackage#getAbstractMethodDeclaration_Body()
     */
    Block getBody();

    /**
     * Sets the value of the '{@link org.eclipse.gmt.modisco.java.AbstractMethodDeclaration#getBody <em>Body</em>}'
     * containment reference.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @param value the new value of the '<em>Body</em>' containment reference.
     *
     * @generated
     * @see #getBody()
     */
    void setBody(Block value);

    /**
     * Returns the value of the '<em><b>Parameters</b></em>' containment reference list.
     * The list contents are of type {@link org.eclipse.gmt.modisco.java.SingleVariableDeclaration}.
     * It is bidirectional and its opposite is '{@link org.eclipse.gmt.modisco.java.SingleVariableDeclaration#getMethodDeclaration
     * <em>Method Declaration</em>}'.
     * <!-- begin-user-doc -->
     * <p>
     * If the meaning of the '<em>Parameters</em>' containment reference list isn't clear,
     * there really should be more of a description here...
     * </p>
     * <!-- end-user-doc -->
     *
     * @return the value of the '<em>Parameters</em>' containment reference list.
     *
     * @model opposite="methodDeclaration" containment="true"
     * @generated
     * @see org.eclipse.gmt.modisco.java.JavaPackage#getAbstractMethodDeclaration_Parameters()
     * @see org.eclipse.gmt.modisco.java.SingleVariableDeclaration#getMethodDeclaration
     */
    EList<SingleVariableDeclaration> getParameters();

    /**
     * Returns the value of the '<em><b>Thrown Exceptions</b></em>' containment reference list.
     * The list contents are of type {@link org.eclipse.gmt.modisco.java.TypeAccess}.
     * <!-- begin-user-doc -->
     * <p>
     * If the meaning of the '<em>Thrown Exceptions</em>' containment reference list isn't clear,
     * there really should be more of a description here...
     * </p>
     * <!-- end-user-doc -->
     *
     * @return the value of the '<em>Thrown Exceptions</em>' containment reference list.
     *
     * @model containment="true"
     * @generated
     * @see org.eclipse.gmt.modisco.java.JavaPackage#getAbstractMethodDeclaration_ThrownExceptions()
     */
    EList<TypeAccess> getThrownExceptions();

    /**
     * Returns the value of the '<em><b>Type Parameters</b></em>' containment reference list.
     * The list contents are of type {@link org.eclipse.gmt.modisco.java.TypeParameter}.
     * <!-- begin-user-doc -->
     * <p>
     * If the meaning of the '<em>Type Parameters</em>' containment reference list isn't clear,
     * there really should be more of a description here...
     * </p>
     * <!-- end-user-doc -->
     *
     * @return the value of the '<em>Type Parameters</em>' containment reference list.
     *
     * @model containment="true"
     * @generated
     * @see org.eclipse.gmt.modisco.java.JavaPackage#getAbstractMethodDeclaration_TypeParameters()
     */
    EList<TypeParameter> getTypeParameters();

    /**
     * Returns the value of the '<em><b>Usages In Doc Comments</b></em>' reference list.
     * The list contents are of type {@link org.eclipse.gmt.modisco.java.MethodRef}.
     * It is bidirectional and its opposite is '{@link org.eclipse.gmt.modisco.java.MethodRef#getMethod
     * <em>Method</em>}'.
     * <!-- begin-user-doc -->
     * <p>
     * If the meaning of the '<em>Usages In Doc Comments</em>' reference list isn't clear,
     * there really should be more of a description here...
     * </p>
     * <!-- end-user-doc -->
     *
     * @return the value of the '<em>Usages In Doc Comments</em>' reference list.
     *
     * @model opposite="method" ordered="false"
     * @generated
     * @see org.eclipse.gmt.modisco.java.JavaPackage#getAbstractMethodDeclaration_UsagesInDocComments()
     * @see org.eclipse.gmt.modisco.java.MethodRef#getMethod
     */
    EList<MethodRef> getUsagesInDocComments();

    /**
     * Returns the value of the '<em><b>Usages</b></em>' reference list.
     * The list contents are of type {@link org.eclipse.gmt.modisco.java.AbstractMethodInvocation}.
     * It is bidirectional and its opposite is '{@link org.eclipse.gmt.modisco.java.AbstractMethodInvocation#getMethod
     * <em>Method</em>}'.
     * <!-- begin-user-doc -->
     * <p>
     * If the meaning of the '<em>Usages</em>' reference list isn't clear,
     * there really should be more of a description here...
     * </p>
     * <!-- end-user-doc -->
     *
     * @return the value of the '<em>Usages</em>' reference list.
     *
     * @model opposite="method" ordered="false"
     * @generated
     * @see org.eclipse.gmt.modisco.java.JavaPackage#getAbstractMethodDeclaration_Usages()
     * @see org.eclipse.gmt.modisco.java.AbstractMethodInvocation#getMethod
     */
    EList<AbstractMethodInvocation> getUsages();

} // AbstractMethodDeclaration
