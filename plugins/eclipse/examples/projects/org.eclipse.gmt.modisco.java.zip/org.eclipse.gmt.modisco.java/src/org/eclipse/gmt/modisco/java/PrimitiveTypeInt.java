/**
 */
package org.eclipse.gmt.modisco.java;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Primitive Type Int</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.gmt.modisco.java.JavaPackage#getPrimitiveTypeInt()
 * @model
 * @generated
 */
public interface PrimitiveTypeInt extends PrimitiveType {
} // PrimitiveTypeInt
