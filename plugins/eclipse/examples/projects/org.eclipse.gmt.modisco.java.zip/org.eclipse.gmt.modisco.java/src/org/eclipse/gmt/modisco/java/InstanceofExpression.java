/**
 */

package org.eclipse.gmt.modisco.java;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Instanceof Expression</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 * <li>{@link org.eclipse.gmt.modisco.java.InstanceofExpression#getRightOperand <em>Right Operand</em>}</li>
 * <li>{@link org.eclipse.gmt.modisco.java.InstanceofExpression#getLeftOperand <em>Left Operand</em>}</li>
 * </ul>
 *
 * @model
 * @generated
 * @see org.eclipse.gmt.modisco.java.JavaPackage#getInstanceofExpression()
 */
public interface InstanceofExpression extends Expression {

    /**
     * Returns the value of the '<em><b>Right Operand</b></em>' containment reference.
     * <!-- begin-user-doc -->
     * <p>
     * If the meaning of the '<em>Right Operand</em>' containment reference isn't clear,
     * there really should be more of a description here...
     * </p>
     * <!-- end-user-doc -->
     *
     * @return the value of the '<em>Right Operand</em>' containment reference.
     *
     * @model containment="true" required="true" ordered="false"
     * @generated
     * @see #setRightOperand(TypeAccess)
     * @see org.eclipse.gmt.modisco.java.JavaPackage#getInstanceofExpression_RightOperand()
     */
    TypeAccess getRightOperand();

    /**
     * Sets the value of the '{@link org.eclipse.gmt.modisco.java.InstanceofExpression#getRightOperand <em>Right
     * Operand</em>}' containment reference.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @param value the new value of the '<em>Right Operand</em>' containment reference.
     *
     * @generated
     * @see #getRightOperand()
     */
    void setRightOperand(TypeAccess value);

    /**
     * Returns the value of the '<em><b>Left Operand</b></em>' containment reference.
     * <!-- begin-user-doc -->
     * <p>
     * If the meaning of the '<em>Left Operand</em>' containment reference isn't clear,
     * there really should be more of a description here...
     * </p>
     * <!-- end-user-doc -->
     *
     * @return the value of the '<em>Left Operand</em>' containment reference.
     *
     * @model containment="true" required="true" ordered="false"
     * @generated
     * @see #setLeftOperand(Expression)
     * @see org.eclipse.gmt.modisco.java.JavaPackage#getInstanceofExpression_LeftOperand()
     */
    Expression getLeftOperand();

    /**
     * Sets the value of the '{@link org.eclipse.gmt.modisco.java.InstanceofExpression#getLeftOperand <em>Left
     * Operand</em>}' containment reference.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @param value the new value of the '<em>Left Operand</em>' containment reference.
     *
     * @generated
     * @see #getLeftOperand()
     */
    void setLeftOperand(Expression value);

} // InstanceofExpression
