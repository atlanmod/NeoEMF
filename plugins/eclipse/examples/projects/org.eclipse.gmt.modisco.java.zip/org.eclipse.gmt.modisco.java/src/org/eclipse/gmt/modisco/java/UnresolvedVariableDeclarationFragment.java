/**
 */
package org.eclipse.gmt.modisco.java;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Unresolved Variable Declaration Fragment</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.gmt.modisco.java.JavaPackage#getUnresolvedVariableDeclarationFragment()
 * @model
 * @generated
 */
public interface UnresolvedVariableDeclarationFragment extends VariableDeclarationFragment, UnresolvedItem {
} // UnresolvedVariableDeclarationFragment
