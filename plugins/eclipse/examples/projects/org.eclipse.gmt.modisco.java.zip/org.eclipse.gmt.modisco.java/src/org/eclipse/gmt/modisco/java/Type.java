/**
 */

package org.eclipse.gmt.modisco.java;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Type</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 * <li>{@link org.eclipse.gmt.modisco.java.Type#getUsagesInTypeAccess <em>Usages In Type Access</em>}</li>
 * </ul>
 *
 * @model abstract="true"
 * @generated
 * @see org.eclipse.gmt.modisco.java.JavaPackage#getType()
 */
public interface Type extends NamedElement {

    /**
     * Returns the value of the '<em><b>Usages In Type Access</b></em>' reference list.
     * The list contents are of type {@link org.eclipse.gmt.modisco.java.TypeAccess}.
     * It is bidirectional and its opposite is '{@link org.eclipse.gmt.modisco.java.TypeAccess#getType <em>Type</em>}'.
     * <!-- begin-user-doc -->
     * <p>
     * If the meaning of the '<em>Usages In Type Access</em>' reference list isn't clear,
     * there really should be more of a description here...
     * </p>
     * <!-- end-user-doc -->
     *
     * @return the value of the '<em>Usages In Type Access</em>' reference list.
     *
     * @model opposite="type" ordered="false"
     * @generated
     * @see org.eclipse.gmt.modisco.java.JavaPackage#getType_UsagesInTypeAccess()
     * @see org.eclipse.gmt.modisco.java.TypeAccess#getType
     */
    EList<TypeAccess> getUsagesInTypeAccess();

} // Type
