/**
 */

package org.eclipse.gmt.modisco.java;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Expression</b></em>'.
 * <!-- end-user-doc -->
 *
 * @model abstract="true"
 * @generated
 * @see org.eclipse.gmt.modisco.java.JavaPackage#getExpression()
 */
public interface Expression extends ASTNode {
} // Expression
