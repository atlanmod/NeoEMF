/**
 */

package org.eclipse.gmt.modisco.java;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Cast Expression</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 * <li>{@link org.eclipse.gmt.modisco.java.CastExpression#getExpression <em>Expression</em>}</li>
 * <li>{@link org.eclipse.gmt.modisco.java.CastExpression#getType <em>Type</em>}</li>
 * </ul>
 *
 * @model
 * @generated
 * @see org.eclipse.gmt.modisco.java.JavaPackage#getCastExpression()
 */
public interface CastExpression extends Expression {

    /**
     * Returns the value of the '<em><b>Expression</b></em>' containment reference.
     * <!-- begin-user-doc -->
     * <p>
     * If the meaning of the '<em>Expression</em>' containment reference isn't clear,
     * there really should be more of a description here...
     * </p>
     * <!-- end-user-doc -->
     *
     * @return the value of the '<em>Expression</em>' containment reference.
     *
     * @model containment="true" required="true" ordered="false"
     * @generated
     * @see #setExpression(Expression)
     * @see org.eclipse.gmt.modisco.java.JavaPackage#getCastExpression_Expression()
     */
    Expression getExpression();

    /**
     * Sets the value of the '{@link org.eclipse.gmt.modisco.java.CastExpression#getExpression <em>Expression</em>}'
     * containment reference.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @param value the new value of the '<em>Expression</em>' containment reference.
     *
     * @generated
     * @see #getExpression()
     */
    void setExpression(Expression value);

    /**
     * Returns the value of the '<em><b>Type</b></em>' containment reference.
     * <!-- begin-user-doc -->
     * <p>
     * If the meaning of the '<em>Type</em>' containment reference isn't clear,
     * there really should be more of a description here...
     * </p>
     * <!-- end-user-doc -->
     *
     * @return the value of the '<em>Type</em>' containment reference.
     *
     * @model containment="true" required="true" ordered="false"
     * @generated
     * @see #setType(TypeAccess)
     * @see org.eclipse.gmt.modisco.java.JavaPackage#getCastExpression_Type()
     */
    TypeAccess getType();

    /**
     * Sets the value of the '{@link org.eclipse.gmt.modisco.java.CastExpression#getType <em>Type</em>}' containment
     * reference.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @param value the new value of the '<em>Type</em>' containment reference.
     *
     * @generated
     * @see #getType()
     */
    void setType(TypeAccess value);

} // CastExpression
