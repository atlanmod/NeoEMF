/**
 */

package org.eclipse.gmt.modisco.java;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Annotation Member Value Pair</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 * <li>{@link org.eclipse.gmt.modisco.java.AnnotationMemberValuePair#getMember <em>Member</em>}</li>
 * <li>{@link org.eclipse.gmt.modisco.java.AnnotationMemberValuePair#getValue <em>Value</em>}</li>
 * </ul>
 *
 * @model
 * @generated
 * @see org.eclipse.gmt.modisco.java.JavaPackage#getAnnotationMemberValuePair()
 */
public interface AnnotationMemberValuePair extends NamedElement {

    /**
     * Returns the value of the '<em><b>Member</b></em>' reference.
     * It is bidirectional and its opposite is '{@link org.eclipse.gmt.modisco.java.AnnotationTypeMemberDeclaration#getUsages
     * <em>Usages</em>}'.
     * <!-- begin-user-doc -->
     * <p>
     * If the meaning of the '<em>Member</em>' reference isn't clear,
     * there really should be more of a description here...
     * </p>
     * <!-- end-user-doc -->
     *
     * @return the value of the '<em>Member</em>' reference.
     *
     * @model opposite="usages" ordered="false"
     * @generated
     * @see #setMember(AnnotationTypeMemberDeclaration)
     * @see org.eclipse.gmt.modisco.java.JavaPackage#getAnnotationMemberValuePair_Member()
     * @see org.eclipse.gmt.modisco.java.AnnotationTypeMemberDeclaration#getUsages
     */
    AnnotationTypeMemberDeclaration getMember();

    /**
     * Sets the value of the '{@link org.eclipse.gmt.modisco.java.AnnotationMemberValuePair#getMember <em>Member</em>}'
     * reference.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @param value the new value of the '<em>Member</em>' reference.
     *
     * @generated
     * @see #getMember()
     */
    void setMember(AnnotationTypeMemberDeclaration value);

    /**
     * Returns the value of the '<em><b>Value</b></em>' containment reference.
     * <!-- begin-user-doc -->
     * <p>
     * If the meaning of the '<em>Value</em>' containment reference isn't clear,
     * there really should be more of a description here...
     * </p>
     * <!-- end-user-doc -->
     *
     * @return the value of the '<em>Value</em>' containment reference.
     *
     * @model containment="true" required="true" ordered="false"
     * @generated
     * @see #setValue(Expression)
     * @see org.eclipse.gmt.modisco.java.JavaPackage#getAnnotationMemberValuePair_Value()
     */
    Expression getValue();

    /**
     * Sets the value of the '{@link org.eclipse.gmt.modisco.java.AnnotationMemberValuePair#getValue <em>Value</em>}'
     * containment reference.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @param value the new value of the '<em>Value</em>' containment reference.
     *
     * @generated
     * @see #getValue()
     */
    void setValue(Expression value);

} // AnnotationMemberValuePair
