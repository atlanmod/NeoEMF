/**
 */
package org.eclipse.gmt.modisco.java;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Super Method Invocation</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.gmt.modisco.java.JavaPackage#getSuperMethodInvocation()
 * @model
 * @generated
 */
public interface SuperMethodInvocation extends AbstractTypeQualifiedExpression, AbstractMethodInvocation {
} // SuperMethodInvocation
