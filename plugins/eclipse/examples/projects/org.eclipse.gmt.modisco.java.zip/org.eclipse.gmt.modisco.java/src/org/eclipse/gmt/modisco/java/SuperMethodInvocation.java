/**
 */

package org.eclipse.gmt.modisco.java;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Super Method Invocation</b></em>'.
 * <!-- end-user-doc -->
 *
 * @model
 * @generated
 * @see org.eclipse.gmt.modisco.java.JavaPackage#getSuperMethodInvocation()
 */
public interface SuperMethodInvocation extends AbstractTypeQualifiedExpression, AbstractMethodInvocation {
} // SuperMethodInvocation
