/**
 */

package org.eclipse.gmt.modisco.java;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Boolean Literal</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 * <li>{@link org.eclipse.gmt.modisco.java.BooleanLiteral#isValue <em>Value</em>}</li>
 * </ul>
 *
 * @model
 * @generated
 * @see org.eclipse.gmt.modisco.java.JavaPackage#getBooleanLiteral()
 */
public interface BooleanLiteral extends Expression {

    /**
     * Returns the value of the '<em><b>Value</b></em>' attribute.
     * <!-- begin-user-doc -->
     * <p>
     * If the meaning of the '<em>Value</em>' attribute isn't clear,
     * there really should be more of a description here...
     * </p>
     * <!-- end-user-doc -->
     *
     * @return the value of the '<em>Value</em>' attribute.
     *
     * @model unique="false" required="true" ordered="false"
     * @generated
     * @see #setValue(boolean)
     * @see org.eclipse.gmt.modisco.java.JavaPackage#getBooleanLiteral_Value()
     */
    boolean isValue();

    /**
     * Sets the value of the '{@link org.eclipse.gmt.modisco.java.BooleanLiteral#isValue <em>Value</em>}' attribute.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @param value the new value of the '<em>Value</em>' attribute.
     *
     * @generated
     * @see #isValue()
     */
    void setValue(boolean value);

} // BooleanLiteral
