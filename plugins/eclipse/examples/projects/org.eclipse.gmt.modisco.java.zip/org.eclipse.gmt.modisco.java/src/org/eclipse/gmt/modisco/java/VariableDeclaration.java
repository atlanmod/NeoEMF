/**
 */

package org.eclipse.gmt.modisco.java;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Variable Declaration</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 * <li>{@link org.eclipse.gmt.modisco.java.VariableDeclaration#getExtraArrayDimensions <em>Extra Array
 * Dimensions</em>}</li>
 * <li>{@link org.eclipse.gmt.modisco.java.VariableDeclaration#getInitializer <em>Initializer</em>}</li>
 * <li>{@link org.eclipse.gmt.modisco.java.VariableDeclaration#getUsageInVariableAccess <em>Usage In Variable
 * Access</em>}</li>
 * </ul>
 *
 * @model abstract="true"
 * @generated
 * @see org.eclipse.gmt.modisco.java.JavaPackage#getVariableDeclaration()
 */
public interface VariableDeclaration extends NamedElement {

    /**
     * Returns the value of the '<em><b>Extra Array Dimensions</b></em>' attribute.
     * <!-- begin-user-doc -->
     * <p>
     * If the meaning of the '<em>Extra Array Dimensions</em>' attribute isn't clear,
     * there really should be more of a description here...
     * </p>
     * <!-- end-user-doc -->
     *
     * @return the value of the '<em>Extra Array Dimensions</em>' attribute.
     *
     * @model unique="false" required="true" ordered="false"
     * @generated
     * @see #setExtraArrayDimensions(int)
     * @see org.eclipse.gmt.modisco.java.JavaPackage#getVariableDeclaration_ExtraArrayDimensions()
     */
    int getExtraArrayDimensions();

    /**
     * Sets the value of the '{@link org.eclipse.gmt.modisco.java.VariableDeclaration#getExtraArrayDimensions <em>Extra
     * Array Dimensions</em>}' attribute.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @param value the new value of the '<em>Extra Array Dimensions</em>' attribute.
     *
     * @generated
     * @see #getExtraArrayDimensions()
     */
    void setExtraArrayDimensions(int value);

    /**
     * Returns the value of the '<em><b>Initializer</b></em>' containment reference.
     * <!-- begin-user-doc -->
     * <p>
     * If the meaning of the '<em>Initializer</em>' containment reference isn't clear,
     * there really should be more of a description here...
     * </p>
     * <!-- end-user-doc -->
     *
     * @return the value of the '<em>Initializer</em>' containment reference.
     *
     * @model containment="true" ordered="false"
     * @generated
     * @see #setInitializer(Expression)
     * @see org.eclipse.gmt.modisco.java.JavaPackage#getVariableDeclaration_Initializer()
     */
    Expression getInitializer();

    /**
     * Sets the value of the '{@link org.eclipse.gmt.modisco.java.VariableDeclaration#getInitializer
     * <em>Initializer</em>}' containment reference.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @param value the new value of the '<em>Initializer</em>' containment reference.
     *
     * @generated
     * @see #getInitializer()
     */
    void setInitializer(Expression value);

    /**
     * Returns the value of the '<em><b>Usage In Variable Access</b></em>' reference list.
     * The list contents are of type {@link org.eclipse.gmt.modisco.java.SingleVariableAccess}.
     * It is bidirectional and its opposite is '{@link org.eclipse.gmt.modisco.java.SingleVariableAccess#getVariable
     * <em>Variable</em>}'.
     * <!-- begin-user-doc -->
     * <p>
     * If the meaning of the '<em>Usage In Variable Access</em>' reference list isn't clear,
     * there really should be more of a description here...
     * </p>
     * <!-- end-user-doc -->
     *
     * @return the value of the '<em>Usage In Variable Access</em>' reference list.
     *
     * @model opposite="variable" ordered="false"
     * @generated
     * @see org.eclipse.gmt.modisco.java.JavaPackage#getVariableDeclaration_UsageInVariableAccess()
     * @see org.eclipse.gmt.modisco.java.SingleVariableAccess#getVariable
     */
    EList<SingleVariableAccess> getUsageInVariableAccess();

} // VariableDeclaration
