/**
 */
package org.eclipse.gmt.modisco.java;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Empty Statement</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.gmt.modisco.java.JavaPackage#getEmptyStatement()
 * @model
 * @generated
 */
public interface EmptyStatement extends Statement {
} // EmptyStatement
