/**
 */
package org.eclipse.gmt.modisco.java;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Null Literal</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.gmt.modisco.java.JavaPackage#getNullLiteral()
 * @model
 * @generated
 */
public interface NullLiteral extends Expression {
} // NullLiteral
