/**
 */

package org.eclipse.gmt.modisco.java;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Package</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 * <li>{@link org.eclipse.gmt.modisco.java.Package#getOwnedElements <em>Owned Elements</em>}</li>
 * <li>{@link org.eclipse.gmt.modisco.java.Package#getModel <em>Model</em>}</li>
 * <li>{@link org.eclipse.gmt.modisco.java.Package#getOwnedPackages <em>Owned Packages</em>}</li>
 * <li>{@link org.eclipse.gmt.modisco.java.Package#getPackage <em>Package</em>}</li>
 * <li>{@link org.eclipse.gmt.modisco.java.Package#getUsagesInPackageAccess <em>Usages In Package Access</em>}</li>
 * </ul>
 *
 * @model
 * @generated
 * @see org.eclipse.gmt.modisco.java.JavaPackage#getPackage()
 */
public interface Package extends NamedElement {

    /**
     * Returns the value of the '<em><b>Owned Elements</b></em>' containment reference list.
     * The list contents are of type {@link org.eclipse.gmt.modisco.java.AbstractTypeDeclaration}.
     * It is bidirectional and its opposite is '{@link org.eclipse.gmt.modisco.java.AbstractTypeDeclaration#getPackage
     * <em>Package</em>}'.
     * <!-- begin-user-doc -->
     * <p>
     * If the meaning of the '<em>Owned Elements</em>' containment reference list isn't clear,
     * there really should be more of a description here...
     * </p>
     * <!-- end-user-doc -->
     *
     * @return the value of the '<em>Owned Elements</em>' containment reference list.
     *
     * @model opposite="package" containment="true" ordered="false"
     * @generated
     * @see org.eclipse.gmt.modisco.java.JavaPackage#getPackage_OwnedElements()
     * @see org.eclipse.gmt.modisco.java.AbstractTypeDeclaration#getPackage
     */
    EList<AbstractTypeDeclaration> getOwnedElements();

    /**
     * Returns the value of the '<em><b>Model</b></em>' container reference.
     * It is bidirectional and its opposite is '{@link org.eclipse.gmt.modisco.java.Model#getOwnedElements <em>Owned
     * Elements</em>}'.
     * <!-- begin-user-doc -->
     * <p>
     * If the meaning of the '<em>Model</em>' container reference isn't clear,
     * there really should be more of a description here...
     * </p>
     * <!-- end-user-doc -->
     *
     * @return the value of the '<em>Model</em>' container reference.
     *
     * @model opposite="ownedElements" transient="false" ordered="false"
     * @generated
     * @see #setModel(Model)
     * @see org.eclipse.gmt.modisco.java.JavaPackage#getPackage_Model()
     * @see org.eclipse.gmt.modisco.java.Model#getOwnedElements
     */
    Model getModel();

    /**
     * Sets the value of the '{@link org.eclipse.gmt.modisco.java.Package#getModel <em>Model</em>}' container reference.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @param value the new value of the '<em>Model</em>' container reference.
     *
     * @generated
     * @see #getModel()
     */
    void setModel(Model value);

    /**
     * Returns the value of the '<em><b>Owned Packages</b></em>' containment reference list.
     * The list contents are of type {@link org.eclipse.gmt.modisco.java.Package}.
     * It is bidirectional and its opposite is '{@link org.eclipse.gmt.modisco.java.Package#getPackage
     * <em>Package</em>}'.
     * <!-- begin-user-doc -->
     * <p>
     * If the meaning of the '<em>Owned Packages</em>' containment reference list isn't clear,
     * there really should be more of a description here...
     * </p>
     * <!-- end-user-doc -->
     *
     * @return the value of the '<em>Owned Packages</em>' containment reference list.
     *
     * @model opposite="package" containment="true" ordered="false"
     * @generated
     * @see org.eclipse.gmt.modisco.java.JavaPackage#getPackage_OwnedPackages()
     * @see org.eclipse.gmt.modisco.java.Package#getPackage
     */
    EList<Package> getOwnedPackages();

    /**
     * Returns the value of the '<em><b>Package</b></em>' container reference.
     * It is bidirectional and its opposite is '{@link org.eclipse.gmt.modisco.java.Package#getOwnedPackages <em>Owned
     * Packages</em>}'.
     * <!-- begin-user-doc -->
     * <p>
     * If the meaning of the '<em>Package</em>' container reference isn't clear,
     * there really should be more of a description here...
     * </p>
     * <!-- end-user-doc -->
     *
     * @return the value of the '<em>Package</em>' container reference.
     *
     * @model opposite="ownedPackages" transient="false" ordered="false"
     * @generated
     * @see #setPackage(Package)
     * @see org.eclipse.gmt.modisco.java.JavaPackage#getPackage_Package()
     * @see org.eclipse.gmt.modisco.java.Package#getOwnedPackages
     */
    Package getPackage();

    /**
     * Sets the value of the '{@link org.eclipse.gmt.modisco.java.Package#getPackage <em>Package</em>}' container
     * reference.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @param value the new value of the '<em>Package</em>' container reference.
     *
     * @generated
     * @see #getPackage()
     */
    void setPackage(Package value);

    /**
     * Returns the value of the '<em><b>Usages In Package Access</b></em>' reference list.
     * The list contents are of type {@link org.eclipse.gmt.modisco.java.PackageAccess}.
     * It is bidirectional and its opposite is '{@link org.eclipse.gmt.modisco.java.PackageAccess#getPackage
     * <em>Package</em>}'.
     * <!-- begin-user-doc -->
     * <p>
     * If the meaning of the '<em>Usages In Package Access</em>' reference list isn't clear,
     * there really should be more of a description here...
     * </p>
     * <!-- end-user-doc -->
     *
     * @return the value of the '<em>Usages In Package Access</em>' reference list.
     *
     * @model opposite="package" ordered="false"
     * @generated
     * @see org.eclipse.gmt.modisco.java.JavaPackage#getPackage_UsagesInPackageAccess()
     * @see org.eclipse.gmt.modisco.java.PackageAccess#getPackage
     */
    EList<PackageAccess> getUsagesInPackageAccess();

} // Package
