/**
 */

package org.eclipse.gmt.modisco.java;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>For Statement</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 * <li>{@link org.eclipse.gmt.modisco.java.ForStatement#getExpression <em>Expression</em>}</li>
 * <li>{@link org.eclipse.gmt.modisco.java.ForStatement#getUpdaters <em>Updaters</em>}</li>
 * <li>{@link org.eclipse.gmt.modisco.java.ForStatement#getInitializers <em>Initializers</em>}</li>
 * <li>{@link org.eclipse.gmt.modisco.java.ForStatement#getBody <em>Body</em>}</li>
 * </ul>
 *
 * @model
 * @generated
 * @see org.eclipse.gmt.modisco.java.JavaPackage#getForStatement()
 */
public interface ForStatement extends Statement {

    /**
     * Returns the value of the '<em><b>Expression</b></em>' containment reference.
     * <!-- begin-user-doc -->
     * <p>
     * If the meaning of the '<em>Expression</em>' containment reference isn't clear,
     * there really should be more of a description here...
     * </p>
     * <!-- end-user-doc -->
     *
     * @return the value of the '<em>Expression</em>' containment reference.
     *
     * @model containment="true" ordered="false"
     * @generated
     * @see #setExpression(Expression)
     * @see org.eclipse.gmt.modisco.java.JavaPackage#getForStatement_Expression()
     */
    Expression getExpression();

    /**
     * Sets the value of the '{@link org.eclipse.gmt.modisco.java.ForStatement#getExpression <em>Expression</em>}'
     * containment reference.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @param value the new value of the '<em>Expression</em>' containment reference.
     *
     * @generated
     * @see #getExpression()
     */
    void setExpression(Expression value);

    /**
     * Returns the value of the '<em><b>Updaters</b></em>' containment reference list.
     * The list contents are of type {@link org.eclipse.gmt.modisco.java.Expression}.
     * <!-- begin-user-doc -->
     * <p>
     * If the meaning of the '<em>Updaters</em>' containment reference list isn't clear,
     * there really should be more of a description here...
     * </p>
     * <!-- end-user-doc -->
     *
     * @return the value of the '<em>Updaters</em>' containment reference list.
     *
     * @model containment="true"
     * @generated
     * @see org.eclipse.gmt.modisco.java.JavaPackage#getForStatement_Updaters()
     */
    EList<Expression> getUpdaters();

    /**
     * Returns the value of the '<em><b>Initializers</b></em>' containment reference list.
     * The list contents are of type {@link org.eclipse.gmt.modisco.java.Expression}.
     * <!-- begin-user-doc -->
     * <p>
     * If the meaning of the '<em>Initializers</em>' containment reference list isn't clear,
     * there really should be more of a description here...
     * </p>
     * <!-- end-user-doc -->
     *
     * @return the value of the '<em>Initializers</em>' containment reference list.
     *
     * @model containment="true"
     * @generated
     * @see org.eclipse.gmt.modisco.java.JavaPackage#getForStatement_Initializers()
     */
    EList<Expression> getInitializers();

    /**
     * Returns the value of the '<em><b>Body</b></em>' containment reference.
     * <!-- begin-user-doc -->
     * <p>
     * If the meaning of the '<em>Body</em>' containment reference isn't clear,
     * there really should be more of a description here...
     * </p>
     * <!-- end-user-doc -->
     *
     * @return the value of the '<em>Body</em>' containment reference.
     *
     * @model containment="true" required="true" ordered="false"
     * @generated
     * @see #setBody(Statement)
     * @see org.eclipse.gmt.modisco.java.JavaPackage#getForStatement_Body()
     */
    Statement getBody();

    /**
     * Sets the value of the '{@link org.eclipse.gmt.modisco.java.ForStatement#getBody <em>Body</em>}' containment
     * reference.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @param value the new value of the '<em>Body</em>' containment reference.
     *
     * @generated
     * @see #getBody()
     */
    void setBody(Statement value);

} // ForStatement
