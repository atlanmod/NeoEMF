/**
 */

package org.eclipse.gmt.modisco.java.util;

import org.eclipse.emf.common.notify.Adapter;
import org.eclipse.emf.common.notify.Notifier;
import org.eclipse.emf.common.notify.impl.AdapterFactoryImpl;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.gmt.modisco.java.*;

/**
 * <!-- begin-user-doc -->
 * The <b>Adapter Factory</b> for the model.
 * It provides an adapter <code>createXXX</code> method for each class of the model.
 * <!-- end-user-doc -->
 *
 * @generated
 * @see org.eclipse.gmt.modisco.java.JavaPackage
 */
public class JavaAdapterFactory extends AdapterFactoryImpl {

    /**
     * The cached model package.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected static JavaPackage modelPackage;
    /**
     * The switch that delegates to the <code>createXXX</code> methods.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected JavaSwitch<Adapter> modelSwitch =
            new JavaSwitch<Adapter>() {
                @Override
                public Adapter caseAbstractMethodDeclaration(AbstractMethodDeclaration object) {
                    return createAbstractMethodDeclarationAdapter();
                }

                @Override
                public Adapter caseAbstractMethodInvocation(AbstractMethodInvocation object) {
                    return createAbstractMethodInvocationAdapter();
                }

                @Override
                public Adapter caseAbstractTypeDeclaration(AbstractTypeDeclaration object) {
                    return createAbstractTypeDeclarationAdapter();
                }

                @Override
                public Adapter caseAbstractTypeQualifiedExpression(AbstractTypeQualifiedExpression object) {
                    return createAbstractTypeQualifiedExpressionAdapter();
                }

                @Override
                public Adapter caseAbstractVariablesContainer(AbstractVariablesContainer object) {
                    return createAbstractVariablesContainerAdapter();
                }

                @Override
                public Adapter caseAnnotation(Annotation object) {
                    return createAnnotationAdapter();
                }

                @Override
                public Adapter caseArchive(Archive object) {
                    return createArchiveAdapter();
                }

                @Override
                public Adapter caseAssertStatement(AssertStatement object) {
                    return createAssertStatementAdapter();
                }

                @Override
                public Adapter caseASTNode(ASTNode object) {
                    return createASTNodeAdapter();
                }

                @Override
                public Adapter caseAnnotationMemberValuePair(AnnotationMemberValuePair object) {
                    return createAnnotationMemberValuePairAdapter();
                }

                @Override
                public Adapter caseAnnotationTypeDeclaration(AnnotationTypeDeclaration object) {
                    return createAnnotationTypeDeclarationAdapter();
                }

                @Override
                public Adapter caseAnnotationTypeMemberDeclaration(AnnotationTypeMemberDeclaration object) {
                    return createAnnotationTypeMemberDeclarationAdapter();
                }

                @Override
                public Adapter caseAnonymousClassDeclaration(AnonymousClassDeclaration object) {
                    return createAnonymousClassDeclarationAdapter();
                }

                @Override
                public Adapter caseArrayAccess(ArrayAccess object) {
                    return createArrayAccessAdapter();
                }

                @Override
                public Adapter caseArrayCreation(ArrayCreation object) {
                    return createArrayCreationAdapter();
                }

                @Override
                public Adapter caseArrayInitializer(ArrayInitializer object) {
                    return createArrayInitializerAdapter();
                }

                @Override
                public Adapter caseArrayLengthAccess(ArrayLengthAccess object) {
                    return createArrayLengthAccessAdapter();
                }

                @Override
                public Adapter caseArrayType(ArrayType object) {
                    return createArrayTypeAdapter();
                }

                @Override
                public Adapter caseAssignment(Assignment object) {
                    return createAssignmentAdapter();
                }

                @Override
                public Adapter caseBodyDeclaration(BodyDeclaration object) {
                    return createBodyDeclarationAdapter();
                }

                @Override
                public Adapter caseBooleanLiteral(BooleanLiteral object) {
                    return createBooleanLiteralAdapter();
                }

                @Override
                public Adapter caseBlockComment(BlockComment object) {
                    return createBlockCommentAdapter();
                }

                @Override
                public Adapter caseBlock(Block object) {
                    return createBlockAdapter();
                }

                @Override
                public Adapter caseBreakStatement(BreakStatement object) {
                    return createBreakStatementAdapter();
                }

                @Override
                public Adapter caseCastExpression(CastExpression object) {
                    return createCastExpressionAdapter();
                }

                @Override
                public Adapter caseCatchClause(CatchClause object) {
                    return createCatchClauseAdapter();
                }

                @Override
                public Adapter caseCharacterLiteral(CharacterLiteral object) {
                    return createCharacterLiteralAdapter();
                }

                @Override
                public Adapter caseClassFile(ClassFile object) {
                    return createClassFileAdapter();
                }

                @Override
                public Adapter caseClassInstanceCreation(ClassInstanceCreation object) {
                    return createClassInstanceCreationAdapter();
                }

                @Override
                public Adapter caseConstructorDeclaration(ConstructorDeclaration object) {
                    return createConstructorDeclarationAdapter();
                }

                @Override
                public Adapter caseConditionalExpression(ConditionalExpression object) {
                    return createConditionalExpressionAdapter();
                }

                @Override
                public Adapter caseConstructorInvocation(ConstructorInvocation object) {
                    return createConstructorInvocationAdapter();
                }

                @Override
                public Adapter caseClassDeclaration(ClassDeclaration object) {
                    return createClassDeclarationAdapter();
                }

                @Override
                public Adapter caseComment(Comment object) {
                    return createCommentAdapter();
                }

                @Override
                public Adapter caseCompilationUnit(CompilationUnit object) {
                    return createCompilationUnitAdapter();
                }

                @Override
                public Adapter caseContinueStatement(ContinueStatement object) {
                    return createContinueStatementAdapter();
                }

                @Override
                public Adapter caseDoStatement(DoStatement object) {
                    return createDoStatementAdapter();
                }

                @Override
                public Adapter caseEmptyStatement(EmptyStatement object) {
                    return createEmptyStatementAdapter();
                }

                @Override
                public Adapter caseEnhancedForStatement(EnhancedForStatement object) {
                    return createEnhancedForStatementAdapter();
                }

                @Override
                public Adapter caseEnumConstantDeclaration(EnumConstantDeclaration object) {
                    return createEnumConstantDeclarationAdapter();
                }

                @Override
                public Adapter caseEnumDeclaration(EnumDeclaration object) {
                    return createEnumDeclarationAdapter();
                }

                @Override
                public Adapter caseExpression(Expression object) {
                    return createExpressionAdapter();
                }

                @Override
                public Adapter caseExpressionStatement(ExpressionStatement object) {
                    return createExpressionStatementAdapter();
                }

                @Override
                public Adapter caseFieldAccess(FieldAccess object) {
                    return createFieldAccessAdapter();
                }

                @Override
                public Adapter caseFieldDeclaration(FieldDeclaration object) {
                    return createFieldDeclarationAdapter();
                }

                @Override
                public Adapter caseForStatement(ForStatement object) {
                    return createForStatementAdapter();
                }

                @Override
                public Adapter caseIfStatement(IfStatement object) {
                    return createIfStatementAdapter();
                }

                @Override
                public Adapter caseImportDeclaration(ImportDeclaration object) {
                    return createImportDeclarationAdapter();
                }

                @Override
                public Adapter caseInfixExpression(InfixExpression object) {
                    return createInfixExpressionAdapter();
                }

                @Override
                public Adapter caseInitializer(Initializer object) {
                    return createInitializerAdapter();
                }

                @Override
                public Adapter caseInstanceofExpression(InstanceofExpression object) {
                    return createInstanceofExpressionAdapter();
                }

                @Override
                public Adapter caseInterfaceDeclaration(InterfaceDeclaration object) {
                    return createInterfaceDeclarationAdapter();
                }

                @Override
                public Adapter caseJavadoc(Javadoc object) {
                    return createJavadocAdapter();
                }

                @Override
                public Adapter caseLabeledStatement(LabeledStatement object) {
                    return createLabeledStatementAdapter();
                }

                @Override
                public Adapter caseLineComment(LineComment object) {
                    return createLineCommentAdapter();
                }

                @Override
                public Adapter caseManifest(Manifest object) {
                    return createManifestAdapter();
                }

                @Override
                public Adapter caseManifestAttribute(ManifestAttribute object) {
                    return createManifestAttributeAdapter();
                }

                @Override
                public Adapter caseManifestEntry(ManifestEntry object) {
                    return createManifestEntryAdapter();
                }

                @Override
                public Adapter caseMemberRef(MemberRef object) {
                    return createMemberRefAdapter();
                }

                @Override
                public Adapter caseMethodDeclaration(MethodDeclaration object) {
                    return createMethodDeclarationAdapter();
                }

                @Override
                public Adapter caseMethodInvocation(MethodInvocation object) {
                    return createMethodInvocationAdapter();
                }

                @Override
                public Adapter caseMethodRef(MethodRef object) {
                    return createMethodRefAdapter();
                }

                @Override
                public Adapter caseMethodRefParameter(MethodRefParameter object) {
                    return createMethodRefParameterAdapter();
                }

                @Override
                public Adapter caseModel(Model object) {
                    return createModelAdapter();
                }

                @Override
                public Adapter caseModifier(Modifier object) {
                    return createModifierAdapter();
                }

                @Override
                public Adapter caseNamedElement(NamedElement object) {
                    return createNamedElementAdapter();
                }

                @Override
                public Adapter caseNamespaceAccess(NamespaceAccess object) {
                    return createNamespaceAccessAdapter();
                }

                @Override
                public Adapter caseNumberLiteral(NumberLiteral object) {
                    return createNumberLiteralAdapter();
                }

                @Override
                public Adapter caseNullLiteral(NullLiteral object) {
                    return createNullLiteralAdapter();
                }

                @Override
                public Adapter casePackage(org.eclipse.gmt.modisco.java.Package object) {
                    return createPackageAdapter();
                }

                @Override
                public Adapter casePackageAccess(PackageAccess object) {
                    return createPackageAccessAdapter();
                }

                @Override
                public Adapter caseParameterizedType(ParameterizedType object) {
                    return createParameterizedTypeAdapter();
                }

                @Override
                public Adapter caseParenthesizedExpression(ParenthesizedExpression object) {
                    return createParenthesizedExpressionAdapter();
                }

                @Override
                public Adapter casePostfixExpression(PostfixExpression object) {
                    return createPostfixExpressionAdapter();
                }

                @Override
                public Adapter casePrefixExpression(PrefixExpression object) {
                    return createPrefixExpressionAdapter();
                }

                @Override
                public Adapter casePrimitiveType(PrimitiveType object) {
                    return createPrimitiveTypeAdapter();
                }

                @Override
                public Adapter casePrimitiveTypeBoolean(PrimitiveTypeBoolean object) {
                    return createPrimitiveTypeBooleanAdapter();
                }

                @Override
                public Adapter casePrimitiveTypeByte(PrimitiveTypeByte object) {
                    return createPrimitiveTypeByteAdapter();
                }

                @Override
                public Adapter casePrimitiveTypeChar(PrimitiveTypeChar object) {
                    return createPrimitiveTypeCharAdapter();
                }

                @Override
                public Adapter casePrimitiveTypeDouble(PrimitiveTypeDouble object) {
                    return createPrimitiveTypeDoubleAdapter();
                }

                @Override
                public Adapter casePrimitiveTypeShort(PrimitiveTypeShort object) {
                    return createPrimitiveTypeShortAdapter();
                }

                @Override
                public Adapter casePrimitiveTypeFloat(PrimitiveTypeFloat object) {
                    return createPrimitiveTypeFloatAdapter();
                }

                @Override
                public Adapter casePrimitiveTypeInt(PrimitiveTypeInt object) {
                    return createPrimitiveTypeIntAdapter();
                }

                @Override
                public Adapter casePrimitiveTypeLong(PrimitiveTypeLong object) {
                    return createPrimitiveTypeLongAdapter();
                }

                @Override
                public Adapter casePrimitiveTypeVoid(PrimitiveTypeVoid object) {
                    return createPrimitiveTypeVoidAdapter();
                }

                @Override
                public Adapter caseReturnStatement(ReturnStatement object) {
                    return createReturnStatementAdapter();
                }

                @Override
                public Adapter caseSingleVariableAccess(SingleVariableAccess object) {
                    return createSingleVariableAccessAdapter();
                }

                @Override
                public Adapter caseSingleVariableDeclaration(SingleVariableDeclaration object) {
                    return createSingleVariableDeclarationAdapter();
                }

                @Override
                public Adapter caseStatement(Statement object) {
                    return createStatementAdapter();
                }

                @Override
                public Adapter caseStringLiteral(StringLiteral object) {
                    return createStringLiteralAdapter();
                }

                @Override
                public Adapter caseSuperConstructorInvocation(SuperConstructorInvocation object) {
                    return createSuperConstructorInvocationAdapter();
                }

                @Override
                public Adapter caseSuperFieldAccess(SuperFieldAccess object) {
                    return createSuperFieldAccessAdapter();
                }

                @Override
                public Adapter caseSuperMethodInvocation(SuperMethodInvocation object) {
                    return createSuperMethodInvocationAdapter();
                }

                @Override
                public Adapter caseSwitchCase(SwitchCase object) {
                    return createSwitchCaseAdapter();
                }

                @Override
                public Adapter caseSwitchStatement(SwitchStatement object) {
                    return createSwitchStatementAdapter();
                }

                @Override
                public Adapter caseSynchronizedStatement(SynchronizedStatement object) {
                    return createSynchronizedStatementAdapter();
                }

                @Override
                public Adapter caseTagElement(TagElement object) {
                    return createTagElementAdapter();
                }

                @Override
                public Adapter caseTextElement(TextElement object) {
                    return createTextElementAdapter();
                }

                @Override
                public Adapter caseThisExpression(ThisExpression object) {
                    return createThisExpressionAdapter();
                }

                @Override
                public Adapter caseThrowStatement(ThrowStatement object) {
                    return createThrowStatementAdapter();
                }

                @Override
                public Adapter caseTryStatement(TryStatement object) {
                    return createTryStatementAdapter();
                }

                @Override
                public Adapter caseType(Type object) {
                    return createTypeAdapter();
                }

                @Override
                public Adapter caseTypeAccess(TypeAccess object) {
                    return createTypeAccessAdapter();
                }

                @Override
                public Adapter caseTypeDeclaration(TypeDeclaration object) {
                    return createTypeDeclarationAdapter();
                }

                @Override
                public Adapter caseTypeDeclarationStatement(TypeDeclarationStatement object) {
                    return createTypeDeclarationStatementAdapter();
                }

                @Override
                public Adapter caseTypeLiteral(TypeLiteral object) {
                    return createTypeLiteralAdapter();
                }

                @Override
                public Adapter caseTypeParameter(TypeParameter object) {
                    return createTypeParameterAdapter();
                }

                @Override
                public Adapter caseUnresolvedItem(UnresolvedItem object) {
                    return createUnresolvedItemAdapter();
                }

                @Override
                public Adapter caseUnresolvedItemAccess(UnresolvedItemAccess object) {
                    return createUnresolvedItemAccessAdapter();
                }

                @Override
                public Adapter caseUnresolvedAnnotationDeclaration(UnresolvedAnnotationDeclaration object) {
                    return createUnresolvedAnnotationDeclarationAdapter();
                }

                @Override
                public Adapter caseUnresolvedAnnotationTypeMemberDeclaration(UnresolvedAnnotationTypeMemberDeclaration object) {
                    return createUnresolvedAnnotationTypeMemberDeclarationAdapter();
                }

                @Override
                public Adapter caseUnresolvedClassDeclaration(UnresolvedClassDeclaration object) {
                    return createUnresolvedClassDeclarationAdapter();
                }

                @Override
                public Adapter caseUnresolvedEnumDeclaration(UnresolvedEnumDeclaration object) {
                    return createUnresolvedEnumDeclarationAdapter();
                }

                @Override
                public Adapter caseUnresolvedInterfaceDeclaration(UnresolvedInterfaceDeclaration object) {
                    return createUnresolvedInterfaceDeclarationAdapter();
                }

                @Override
                public Adapter caseUnresolvedLabeledStatement(UnresolvedLabeledStatement object) {
                    return createUnresolvedLabeledStatementAdapter();
                }

                @Override
                public Adapter caseUnresolvedMethodDeclaration(UnresolvedMethodDeclaration object) {
                    return createUnresolvedMethodDeclarationAdapter();
                }

                @Override
                public Adapter caseUnresolvedSingleVariableDeclaration(UnresolvedSingleVariableDeclaration object) {
                    return createUnresolvedSingleVariableDeclarationAdapter();
                }

                @Override
                public Adapter caseUnresolvedType(UnresolvedType object) {
                    return createUnresolvedTypeAdapter();
                }

                @Override
                public Adapter caseUnresolvedTypeDeclaration(UnresolvedTypeDeclaration object) {
                    return createUnresolvedTypeDeclarationAdapter();
                }

                @Override
                public Adapter caseUnresolvedVariableDeclarationFragment(UnresolvedVariableDeclarationFragment object) {
                    return createUnresolvedVariableDeclarationFragmentAdapter();
                }

                @Override
                public Adapter caseVariableDeclaration(VariableDeclaration object) {
                    return createVariableDeclarationAdapter();
                }

                @Override
                public Adapter caseVariableDeclarationExpression(VariableDeclarationExpression object) {
                    return createVariableDeclarationExpressionAdapter();
                }

                @Override
                public Adapter caseVariableDeclarationFragment(VariableDeclarationFragment object) {
                    return createVariableDeclarationFragmentAdapter();
                }

                @Override
                public Adapter caseVariableDeclarationStatement(VariableDeclarationStatement object) {
                    return createVariableDeclarationStatementAdapter();
                }

                @Override
                public Adapter caseWildCardType(WildCardType object) {
                    return createWildCardTypeAdapter();
                }

                @Override
                public Adapter caseWhileStatement(WhileStatement object) {
                    return createWhileStatementAdapter();
                }

                @Override
                public Adapter defaultCase(EObject object) {
                    return createEObjectAdapter();
                }
            };

    /**
     * Creates an instance of the adapter factory.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    public JavaAdapterFactory() {
        if (modelPackage == null) {
            modelPackage = JavaPackage.eINSTANCE;
        }
    }

    /**
     * Returns whether this factory is applicable for the type of the object.
     * <!-- begin-user-doc -->
     * This implementation returns <code>true</code> if the object is either the model's package or is an instance
     * object of the model.
     * <!-- end-user-doc -->
     *
     * @return whether this factory is applicable for the type of the object.
     *
     * @generated
     */
    @Override
    public boolean isFactoryForType(Object object) {
        if (object == modelPackage) {
            return true;
        }
        if (object instanceof EObject) {
            return ((EObject) object).eClass().getEPackage() == modelPackage;
        }
        return false;
    }

    /**
     * Creates an adapter for the <code>target</code>.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @param target the object to adapt.
     *
     * @return the adapter for the <code>target</code>.
     *
     * @generated
     */
    @Override
    public Adapter createAdapter(Notifier target) {
        return modelSwitch.doSwitch((EObject) target);
    }


    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.AbstractMethodDeclaration
     * <em>Abstract Method Declaration</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.AbstractMethodDeclaration
     */
    public Adapter createAbstractMethodDeclarationAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.AbstractMethodInvocation
     * <em>Abstract Method Invocation</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.AbstractMethodInvocation
     */
    public Adapter createAbstractMethodInvocationAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.AbstractTypeDeclaration
     * <em>Abstract Type Declaration</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.AbstractTypeDeclaration
     */
    public Adapter createAbstractTypeDeclarationAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.AbstractTypeQualifiedExpression
     * <em>Abstract Type Qualified Expression</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.AbstractTypeQualifiedExpression
     */
    public Adapter createAbstractTypeQualifiedExpressionAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.AbstractVariablesContainer
     * <em>Abstract Variables Container</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.AbstractVariablesContainer
     */
    public Adapter createAbstractVariablesContainerAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.Annotation
     * <em>Annotation</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.Annotation
     */
    public Adapter createAnnotationAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.Archive <em>Archive</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.Archive
     */
    public Adapter createArchiveAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.AssertStatement <em>Assert
     * Statement</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.AssertStatement
     */
    public Adapter createAssertStatementAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.ASTNode <em>AST Node</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.ASTNode
     */
    public Adapter createASTNodeAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.AnnotationMemberValuePair
     * <em>Annotation Member Value Pair</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.AnnotationMemberValuePair
     */
    public Adapter createAnnotationMemberValuePairAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.AnnotationTypeDeclaration
     * <em>Annotation Type Declaration</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.AnnotationTypeDeclaration
     */
    public Adapter createAnnotationTypeDeclarationAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.AnnotationTypeMemberDeclaration
     * <em>Annotation Type Member Declaration</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.AnnotationTypeMemberDeclaration
     */
    public Adapter createAnnotationTypeMemberDeclarationAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.AnonymousClassDeclaration
     * <em>Anonymous Class Declaration</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.AnonymousClassDeclaration
     */
    public Adapter createAnonymousClassDeclarationAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.ArrayAccess <em>Array
     * Access</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.ArrayAccess
     */
    public Adapter createArrayAccessAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.ArrayCreation <em>Array
     * Creation</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.ArrayCreation
     */
    public Adapter createArrayCreationAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.ArrayInitializer <em>Array
     * Initializer</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.ArrayInitializer
     */
    public Adapter createArrayInitializerAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.ArrayLengthAccess <em>Array
     * Length Access</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.ArrayLengthAccess
     */
    public Adapter createArrayLengthAccessAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.ArrayType <em>Array
     * Type</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.ArrayType
     */
    public Adapter createArrayTypeAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.Assignment
     * <em>Assignment</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.Assignment
     */
    public Adapter createAssignmentAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.BodyDeclaration <em>Body
     * Declaration</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.BodyDeclaration
     */
    public Adapter createBodyDeclarationAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.BooleanLiteral <em>Boolean
     * Literal</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.BooleanLiteral
     */
    public Adapter createBooleanLiteralAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.BlockComment <em>Block
     * Comment</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.BlockComment
     */
    public Adapter createBlockCommentAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.Block <em>Block</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.Block
     */
    public Adapter createBlockAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.BreakStatement <em>Break
     * Statement</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.BreakStatement
     */
    public Adapter createBreakStatementAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.CastExpression <em>Cast
     * Expression</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.CastExpression
     */
    public Adapter createCastExpressionAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.CatchClause <em>Catch
     * Clause</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.CatchClause
     */
    public Adapter createCatchClauseAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.CharacterLiteral <em>Character
     * Literal</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.CharacterLiteral
     */
    public Adapter createCharacterLiteralAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.ClassFile <em>Class
     * File</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.ClassFile
     */
    public Adapter createClassFileAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.ClassInstanceCreation <em>Class
     * Instance Creation</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.ClassInstanceCreation
     */
    public Adapter createClassInstanceCreationAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.ConstructorDeclaration
     * <em>Constructor Declaration</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.ConstructorDeclaration
     */
    public Adapter createConstructorDeclarationAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.ConditionalExpression
     * <em>Conditional Expression</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.ConditionalExpression
     */
    public Adapter createConditionalExpressionAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.ConstructorInvocation
     * <em>Constructor Invocation</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.ConstructorInvocation
     */
    public Adapter createConstructorInvocationAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.ClassDeclaration <em>Class
     * Declaration</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.ClassDeclaration
     */
    public Adapter createClassDeclarationAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.Comment <em>Comment</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.Comment
     */
    public Adapter createCommentAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.CompilationUnit <em>Compilation
     * Unit</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.CompilationUnit
     */
    public Adapter createCompilationUnitAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.ContinueStatement <em>Continue
     * Statement</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.ContinueStatement
     */
    public Adapter createContinueStatementAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.DoStatement <em>Do
     * Statement</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.DoStatement
     */
    public Adapter createDoStatementAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.EmptyStatement <em>Empty
     * Statement</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.EmptyStatement
     */
    public Adapter createEmptyStatementAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.EnhancedForStatement
     * <em>Enhanced For Statement</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.EnhancedForStatement
     */
    public Adapter createEnhancedForStatementAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.EnumConstantDeclaration
     * <em>Enum Constant Declaration</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.EnumConstantDeclaration
     */
    public Adapter createEnumConstantDeclarationAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.EnumDeclaration <em>Enum
     * Declaration</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.EnumDeclaration
     */
    public Adapter createEnumDeclarationAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.Expression
     * <em>Expression</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.Expression
     */
    public Adapter createExpressionAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.ExpressionStatement
     * <em>Expression Statement</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.ExpressionStatement
     */
    public Adapter createExpressionStatementAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.FieldAccess <em>Field
     * Access</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.FieldAccess
     */
    public Adapter createFieldAccessAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.FieldDeclaration <em>Field
     * Declaration</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.FieldDeclaration
     */
    public Adapter createFieldDeclarationAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.ForStatement <em>For
     * Statement</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.ForStatement
     */
    public Adapter createForStatementAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.IfStatement <em>If
     * Statement</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.IfStatement
     */
    public Adapter createIfStatementAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.ImportDeclaration <em>Import
     * Declaration</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.ImportDeclaration
     */
    public Adapter createImportDeclarationAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.InfixExpression <em>Infix
     * Expression</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.InfixExpression
     */
    public Adapter createInfixExpressionAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.Initializer
     * <em>Initializer</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.Initializer
     */
    public Adapter createInitializerAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.InstanceofExpression
     * <em>Instanceof Expression</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.InstanceofExpression
     */
    public Adapter createInstanceofExpressionAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.InterfaceDeclaration
     * <em>Interface Declaration</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.InterfaceDeclaration
     */
    public Adapter createInterfaceDeclarationAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.Javadoc <em>Javadoc</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.Javadoc
     */
    public Adapter createJavadocAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.LabeledStatement <em>Labeled
     * Statement</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.LabeledStatement
     */
    public Adapter createLabeledStatementAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.LineComment <em>Line
     * Comment</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.LineComment
     */
    public Adapter createLineCommentAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.Manifest <em>Manifest</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.Manifest
     */
    public Adapter createManifestAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.ManifestAttribute <em>Manifest
     * Attribute</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.ManifestAttribute
     */
    public Adapter createManifestAttributeAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.ManifestEntry <em>Manifest
     * Entry</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.ManifestEntry
     */
    public Adapter createManifestEntryAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.MemberRef <em>Member
     * Ref</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.MemberRef
     */
    public Adapter createMemberRefAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.MethodDeclaration <em>Method
     * Declaration</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.MethodDeclaration
     */
    public Adapter createMethodDeclarationAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.MethodInvocation <em>Method
     * Invocation</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.MethodInvocation
     */
    public Adapter createMethodInvocationAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.MethodRef <em>Method
     * Ref</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.MethodRef
     */
    public Adapter createMethodRefAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.MethodRefParameter <em>Method
     * Ref Parameter</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.MethodRefParameter
     */
    public Adapter createMethodRefParameterAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.Model <em>Model</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.Model
     */
    public Adapter createModelAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.Modifier <em>Modifier</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.Modifier
     */
    public Adapter createModifierAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.NamedElement <em>Named
     * Element</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.NamedElement
     */
    public Adapter createNamedElementAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.NamespaceAccess <em>Namespace
     * Access</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.NamespaceAccess
     */
    public Adapter createNamespaceAccessAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.NumberLiteral <em>Number
     * Literal</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.NumberLiteral
     */
    public Adapter createNumberLiteralAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.NullLiteral <em>Null
     * Literal</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.NullLiteral
     */
    public Adapter createNullLiteralAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.Package <em>Package</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.Package
     */
    public Adapter createPackageAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.PackageAccess <em>Package
     * Access</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.PackageAccess
     */
    public Adapter createPackageAccessAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.ParameterizedType
     * <em>Parameterized Type</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.ParameterizedType
     */
    public Adapter createParameterizedTypeAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.ParenthesizedExpression
     * <em>Parenthesized Expression</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.ParenthesizedExpression
     */
    public Adapter createParenthesizedExpressionAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.PostfixExpression <em>Postfix
     * Expression</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.PostfixExpression
     */
    public Adapter createPostfixExpressionAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.PrefixExpression <em>Prefix
     * Expression</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.PrefixExpression
     */
    public Adapter createPrefixExpressionAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.PrimitiveType <em>Primitive
     * Type</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.PrimitiveType
     */
    public Adapter createPrimitiveTypeAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.PrimitiveTypeBoolean
     * <em>Primitive Type Boolean</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.PrimitiveTypeBoolean
     */
    public Adapter createPrimitiveTypeBooleanAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.PrimitiveTypeByte <em>Primitive
     * Type Byte</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.PrimitiveTypeByte
     */
    public Adapter createPrimitiveTypeByteAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.PrimitiveTypeChar <em>Primitive
     * Type Char</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.PrimitiveTypeChar
     */
    public Adapter createPrimitiveTypeCharAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.PrimitiveTypeDouble
     * <em>Primitive Type Double</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.PrimitiveTypeDouble
     */
    public Adapter createPrimitiveTypeDoubleAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.PrimitiveTypeShort
     * <em>Primitive Type Short</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.PrimitiveTypeShort
     */
    public Adapter createPrimitiveTypeShortAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.PrimitiveTypeFloat
     * <em>Primitive Type Float</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.PrimitiveTypeFloat
     */
    public Adapter createPrimitiveTypeFloatAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.PrimitiveTypeInt <em>Primitive
     * Type Int</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.PrimitiveTypeInt
     */
    public Adapter createPrimitiveTypeIntAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.PrimitiveTypeLong <em>Primitive
     * Type Long</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.PrimitiveTypeLong
     */
    public Adapter createPrimitiveTypeLongAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.PrimitiveTypeVoid <em>Primitive
     * Type Void</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.PrimitiveTypeVoid
     */
    public Adapter createPrimitiveTypeVoidAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.ReturnStatement <em>Return
     * Statement</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.ReturnStatement
     */
    public Adapter createReturnStatementAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.SingleVariableAccess <em>Single
     * Variable Access</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.SingleVariableAccess
     */
    public Adapter createSingleVariableAccessAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.SingleVariableDeclaration
     * <em>Single Variable Declaration</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.SingleVariableDeclaration
     */
    public Adapter createSingleVariableDeclarationAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.Statement <em>Statement</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.Statement
     */
    public Adapter createStatementAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.StringLiteral <em>String
     * Literal</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.StringLiteral
     */
    public Adapter createStringLiteralAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.SuperConstructorInvocation
     * <em>Super Constructor Invocation</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.SuperConstructorInvocation
     */
    public Adapter createSuperConstructorInvocationAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.SuperFieldAccess <em>Super
     * Field Access</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.SuperFieldAccess
     */
    public Adapter createSuperFieldAccessAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.SuperMethodInvocation <em>Super
     * Method Invocation</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.SuperMethodInvocation
     */
    public Adapter createSuperMethodInvocationAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.SwitchCase <em>Switch
     * Case</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.SwitchCase
     */
    public Adapter createSwitchCaseAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.SwitchStatement <em>Switch
     * Statement</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.SwitchStatement
     */
    public Adapter createSwitchStatementAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.SynchronizedStatement
     * <em>Synchronized Statement</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.SynchronizedStatement
     */
    public Adapter createSynchronizedStatementAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.TagElement <em>Tag
     * Element</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.TagElement
     */
    public Adapter createTagElementAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.TextElement <em>Text
     * Element</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.TextElement
     */
    public Adapter createTextElementAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.ThisExpression <em>This
     * Expression</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.ThisExpression
     */
    public Adapter createThisExpressionAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.ThrowStatement <em>Throw
     * Statement</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.ThrowStatement
     */
    public Adapter createThrowStatementAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.TryStatement <em>Try
     * Statement</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.TryStatement
     */
    public Adapter createTryStatementAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.Type <em>Type</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.Type
     */
    public Adapter createTypeAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.TypeAccess <em>Type
     * Access</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.TypeAccess
     */
    public Adapter createTypeAccessAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.TypeDeclaration <em>Type
     * Declaration</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.TypeDeclaration
     */
    public Adapter createTypeDeclarationAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.TypeDeclarationStatement
     * <em>Type Declaration Statement</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.TypeDeclarationStatement
     */
    public Adapter createTypeDeclarationStatementAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.TypeLiteral <em>Type
     * Literal</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.TypeLiteral
     */
    public Adapter createTypeLiteralAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.TypeParameter <em>Type
     * Parameter</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.TypeParameter
     */
    public Adapter createTypeParameterAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.UnresolvedItem <em>Unresolved
     * Item</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.UnresolvedItem
     */
    public Adapter createUnresolvedItemAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.UnresolvedItemAccess
     * <em>Unresolved Item Access</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.UnresolvedItemAccess
     */
    public Adapter createUnresolvedItemAccessAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.UnresolvedAnnotationDeclaration
     * <em>Unresolved Annotation Declaration</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.UnresolvedAnnotationDeclaration
     */
    public Adapter createUnresolvedAnnotationDeclarationAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.UnresolvedAnnotationTypeMemberDeclaration
     * <em>Unresolved Annotation Type Member Declaration</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.UnresolvedAnnotationTypeMemberDeclaration
     */
    public Adapter createUnresolvedAnnotationTypeMemberDeclarationAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.UnresolvedClassDeclaration
     * <em>Unresolved Class Declaration</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.UnresolvedClassDeclaration
     */
    public Adapter createUnresolvedClassDeclarationAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.UnresolvedEnumDeclaration
     * <em>Unresolved Enum Declaration</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.UnresolvedEnumDeclaration
     */
    public Adapter createUnresolvedEnumDeclarationAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.UnresolvedInterfaceDeclaration
     * <em>Unresolved Interface Declaration</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.UnresolvedInterfaceDeclaration
     */
    public Adapter createUnresolvedInterfaceDeclarationAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.UnresolvedLabeledStatement
     * <em>Unresolved Labeled Statement</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.UnresolvedLabeledStatement
     */
    public Adapter createUnresolvedLabeledStatementAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.UnresolvedMethodDeclaration
     * <em>Unresolved Method Declaration</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.UnresolvedMethodDeclaration
     */
    public Adapter createUnresolvedMethodDeclarationAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.UnresolvedSingleVariableDeclaration
     * <em>Unresolved Single Variable Declaration</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.UnresolvedSingleVariableDeclaration
     */
    public Adapter createUnresolvedSingleVariableDeclarationAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.UnresolvedType <em>Unresolved
     * Type</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.UnresolvedType
     */
    public Adapter createUnresolvedTypeAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.UnresolvedTypeDeclaration
     * <em>Unresolved Type Declaration</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.UnresolvedTypeDeclaration
     */
    public Adapter createUnresolvedTypeDeclarationAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.UnresolvedVariableDeclarationFragment
     * <em>Unresolved Variable Declaration Fragment</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.UnresolvedVariableDeclarationFragment
     */
    public Adapter createUnresolvedVariableDeclarationFragmentAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.VariableDeclaration
     * <em>Variable Declaration</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.VariableDeclaration
     */
    public Adapter createVariableDeclarationAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.VariableDeclarationExpression
     * <em>Variable Declaration Expression</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.VariableDeclarationExpression
     */
    public Adapter createVariableDeclarationExpressionAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.VariableDeclarationFragment
     * <em>Variable Declaration Fragment</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.VariableDeclarationFragment
     */
    public Adapter createVariableDeclarationFragmentAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.VariableDeclarationStatement
     * <em>Variable Declaration Statement</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.VariableDeclarationStatement
     */
    public Adapter createVariableDeclarationStatementAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.WildCardType <em>Wild Card
     * Type</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.WildCardType
     */
    public Adapter createWildCardTypeAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for an object of class '{@link org.eclipse.gmt.modisco.java.WhileStatement <em>While
     * Statement</em>}'.
     * <!-- begin-user-doc -->
     * This default implementation returns null so that we can easily ignore cases;
     * it's useful to ignore a case when inheritance will catch all the cases anyway.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     * @see org.eclipse.gmt.modisco.java.WhileStatement
     */
    public Adapter createWhileStatementAdapter() {
        return null;
    }

    /**
     * Creates a new adapter for the default case.
     * <!-- begin-user-doc -->
     * This default implementation returns null.
     * <!-- end-user-doc -->
     *
     * @return the new adapter.
     *
     * @generated
     */
    public Adapter createEObjectAdapter() {
        return null;
    }

} //JavaAdapterFactory
