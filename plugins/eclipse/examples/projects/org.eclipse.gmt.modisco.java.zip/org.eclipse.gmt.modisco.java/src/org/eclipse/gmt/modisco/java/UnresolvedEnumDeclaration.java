/**
 */
package org.eclipse.gmt.modisco.java;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Unresolved Enum Declaration</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.gmt.modisco.java.JavaPackage#getUnresolvedEnumDeclaration()
 * @model
 * @generated
 */
public interface UnresolvedEnumDeclaration extends EnumDeclaration, UnresolvedItem {
} // UnresolvedEnumDeclaration
