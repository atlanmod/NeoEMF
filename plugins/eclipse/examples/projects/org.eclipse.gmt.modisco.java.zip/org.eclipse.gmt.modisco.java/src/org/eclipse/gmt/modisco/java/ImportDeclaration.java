/**
 */

package org.eclipse.gmt.modisco.java;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Import Declaration</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 * <li>{@link org.eclipse.gmt.modisco.java.ImportDeclaration#isStatic <em>Static</em>}</li>
 * <li>{@link org.eclipse.gmt.modisco.java.ImportDeclaration#getImportedElement <em>Imported Element</em>}</li>
 * </ul>
 *
 * @model
 * @generated
 * @see org.eclipse.gmt.modisco.java.JavaPackage#getImportDeclaration()
 */
public interface ImportDeclaration extends ASTNode {

    /**
     * Returns the value of the '<em><b>Static</b></em>' attribute.
     * <!-- begin-user-doc -->
     * <p>
     * If the meaning of the '<em>Static</em>' attribute isn't clear,
     * there really should be more of a description here...
     * </p>
     * <!-- end-user-doc -->
     *
     * @return the value of the '<em>Static</em>' attribute.
     *
     * @model unique="false" ordered="false"
     * @generated
     * @see #setStatic(boolean)
     * @see org.eclipse.gmt.modisco.java.JavaPackage#getImportDeclaration_Static()
     */
    boolean isStatic();

    /**
     * Sets the value of the '{@link org.eclipse.gmt.modisco.java.ImportDeclaration#isStatic <em>Static</em>}'
     * attribute.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @param value the new value of the '<em>Static</em>' attribute.
     *
     * @generated
     * @see #isStatic()
     */
    void setStatic(boolean value);

    /**
     * Returns the value of the '<em><b>Imported Element</b></em>' reference.
     * It is bidirectional and its opposite is '{@link org.eclipse.gmt.modisco.java.NamedElement#getUsagesInImports
     * <em>Usages In Imports</em>}'.
     * <!-- begin-user-doc -->
     * <p>
     * If the meaning of the '<em>Imported Element</em>' reference isn't clear,
     * there really should be more of a description here...
     * </p>
     * <!-- end-user-doc -->
     *
     * @return the value of the '<em>Imported Element</em>' reference.
     *
     * @model opposite="usagesInImports" required="true" ordered="false"
     * @generated
     * @see #setImportedElement(NamedElement)
     * @see org.eclipse.gmt.modisco.java.JavaPackage#getImportDeclaration_ImportedElement()
     * @see org.eclipse.gmt.modisco.java.NamedElement#getUsagesInImports
     */
    NamedElement getImportedElement();

    /**
     * Sets the value of the '{@link org.eclipse.gmt.modisco.java.ImportDeclaration#getImportedElement <em>Imported
     * Element</em>}' reference.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @param value the new value of the '<em>Imported Element</em>' reference.
     *
     * @generated
     * @see #getImportedElement()
     */
    void setImportedElement(NamedElement value);

} // ImportDeclaration
