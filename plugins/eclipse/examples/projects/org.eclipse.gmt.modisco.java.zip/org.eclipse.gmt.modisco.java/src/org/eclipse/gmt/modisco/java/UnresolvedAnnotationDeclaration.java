/**
 */
package org.eclipse.gmt.modisco.java;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Unresolved Annotation Declaration</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.gmt.modisco.java.JavaPackage#getUnresolvedAnnotationDeclaration()
 * @model
 * @generated
 */
public interface UnresolvedAnnotationDeclaration extends AnnotationTypeDeclaration, UnresolvedItem {
} // UnresolvedAnnotationDeclaration
