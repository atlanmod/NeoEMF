/**
 */

package org.eclipse.gmt.modisco.java;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Block Comment</b></em>'.
 * <!-- end-user-doc -->
 *
 * @model
 * @generated
 * @see org.eclipse.gmt.modisco.java.JavaPackage#getBlockComment()
 */
public interface BlockComment extends Comment {
} // BlockComment
