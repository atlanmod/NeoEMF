/**
 */
package org.eclipse.gmt.modisco.java;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Primitive Type Long</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.gmt.modisco.java.JavaPackage#getPrimitiveTypeLong()
 * @model
 * @generated
 */
public interface PrimitiveTypeLong extends PrimitiveType {
} // PrimitiveTypeLong
