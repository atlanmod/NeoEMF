/**
 */

package org.eclipse.gmt.modisco.java;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Primitive Type Double</b></em>'.
 * <!-- end-user-doc -->
 *
 * @model
 * @generated
 * @see org.eclipse.gmt.modisco.java.JavaPackage#getPrimitiveTypeDouble()
 */
public interface PrimitiveTypeDouble extends PrimitiveType {
} // PrimitiveTypeDouble
