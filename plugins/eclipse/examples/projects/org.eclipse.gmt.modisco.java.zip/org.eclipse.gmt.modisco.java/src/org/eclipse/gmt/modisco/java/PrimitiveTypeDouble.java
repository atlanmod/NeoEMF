/**
 */
package org.eclipse.gmt.modisco.java;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Primitive Type Double</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.gmt.modisco.java.JavaPackage#getPrimitiveTypeDouble()
 * @model
 * @generated
 */
public interface PrimitiveTypeDouble extends PrimitiveType {
} // PrimitiveTypeDouble
