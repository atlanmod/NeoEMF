/**
 */

package org.eclipse.gmt.modisco.java;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Unresolved Interface Declaration</b></em>'.
 * <!-- end-user-doc -->
 *
 * @model
 * @generated
 * @see org.eclipse.gmt.modisco.java.JavaPackage#getUnresolvedInterfaceDeclaration()
 */
public interface UnresolvedInterfaceDeclaration extends InterfaceDeclaration, UnresolvedItem {
} // UnresolvedInterfaceDeclaration
