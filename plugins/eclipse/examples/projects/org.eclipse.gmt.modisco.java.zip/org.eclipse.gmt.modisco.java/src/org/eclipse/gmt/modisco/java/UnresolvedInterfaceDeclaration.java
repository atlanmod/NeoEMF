/**
 */
package org.eclipse.gmt.modisco.java;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Unresolved Interface Declaration</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.gmt.modisco.java.JavaPackage#getUnresolvedInterfaceDeclaration()
 * @model
 * @generated
 */
public interface UnresolvedInterfaceDeclaration extends InterfaceDeclaration, UnresolvedItem {
} // UnresolvedInterfaceDeclaration
