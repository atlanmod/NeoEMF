/**
 */
package org.eclipse.gmt.modisco.java;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>This Expression</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.gmt.modisco.java.JavaPackage#getThisExpression()
 * @model
 * @generated
 */
public interface ThisExpression extends AbstractTypeQualifiedExpression {
} // ThisExpression
