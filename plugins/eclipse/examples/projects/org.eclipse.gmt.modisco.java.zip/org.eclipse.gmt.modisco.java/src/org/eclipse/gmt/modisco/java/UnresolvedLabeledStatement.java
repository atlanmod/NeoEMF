/**
 */

package org.eclipse.gmt.modisco.java;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Unresolved Labeled Statement</b></em>'.
 * <!-- end-user-doc -->
 *
 * @model
 * @generated
 * @see org.eclipse.gmt.modisco.java.JavaPackage#getUnresolvedLabeledStatement()
 */
public interface UnresolvedLabeledStatement extends LabeledStatement, UnresolvedItem {
} // UnresolvedLabeledStatement
