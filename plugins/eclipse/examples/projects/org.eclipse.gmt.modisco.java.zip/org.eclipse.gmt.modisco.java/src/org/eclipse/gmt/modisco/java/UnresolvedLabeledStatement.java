/**
 */
package org.eclipse.gmt.modisco.java;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Unresolved Labeled Statement</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.gmt.modisco.java.JavaPackage#getUnresolvedLabeledStatement()
 * @model
 * @generated
 */
public interface UnresolvedLabeledStatement extends LabeledStatement, UnresolvedItem {
} // UnresolvedLabeledStatement
