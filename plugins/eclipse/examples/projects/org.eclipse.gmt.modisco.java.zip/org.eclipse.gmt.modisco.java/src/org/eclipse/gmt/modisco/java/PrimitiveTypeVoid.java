/**
 */
package org.eclipse.gmt.modisco.java;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Primitive Type Void</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.gmt.modisco.java.JavaPackage#getPrimitiveTypeVoid()
 * @model
 * @generated
 */
public interface PrimitiveTypeVoid extends PrimitiveType {
} // PrimitiveTypeVoid
