/**
 */

package org.eclipse.gmt.modisco.java.impl;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.gmt.modisco.java.JavaPackage;
import org.eclipse.gmt.modisco.java.PrimitiveTypeChar;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Primitive Type Char</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class PrimitiveTypeCharImpl extends PrimitiveTypeImpl implements PrimitiveTypeChar {

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected PrimitiveTypeCharImpl() {
        super();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    @Override
    protected EClass eStaticClass() {
        return JavaPackage.eINSTANCE.getPrimitiveTypeChar();
    }

} //PrimitiveTypeCharImpl
