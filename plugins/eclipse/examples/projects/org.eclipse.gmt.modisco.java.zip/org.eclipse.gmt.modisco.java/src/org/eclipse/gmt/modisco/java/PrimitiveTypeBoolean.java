/**
 */
package org.eclipse.gmt.modisco.java;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Primitive Type Boolean</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.gmt.modisco.java.JavaPackage#getPrimitiveTypeBoolean()
 * @model
 * @generated
 */
public interface PrimitiveTypeBoolean extends PrimitiveType {
} // PrimitiveTypeBoolean
