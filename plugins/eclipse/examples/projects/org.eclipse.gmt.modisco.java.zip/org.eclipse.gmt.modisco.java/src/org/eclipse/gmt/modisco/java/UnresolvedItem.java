/**
 */
package org.eclipse.gmt.modisco.java;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Unresolved Item</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.gmt.modisco.java.JavaPackage#getUnresolvedItem()
 * @model
 * @generated
 */
public interface UnresolvedItem extends NamedElement {
} // UnresolvedItem
