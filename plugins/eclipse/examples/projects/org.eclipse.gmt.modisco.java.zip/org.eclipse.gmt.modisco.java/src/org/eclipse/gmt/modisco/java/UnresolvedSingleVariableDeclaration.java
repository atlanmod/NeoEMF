/**
 */

package org.eclipse.gmt.modisco.java;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Unresolved Single Variable Declaration</b></em>'.
 * <!-- end-user-doc -->
 *
 * @model
 * @generated
 * @see org.eclipse.gmt.modisco.java.JavaPackage#getUnresolvedSingleVariableDeclaration()
 */
public interface UnresolvedSingleVariableDeclaration extends SingleVariableDeclaration, UnresolvedItem {
} // UnresolvedSingleVariableDeclaration
