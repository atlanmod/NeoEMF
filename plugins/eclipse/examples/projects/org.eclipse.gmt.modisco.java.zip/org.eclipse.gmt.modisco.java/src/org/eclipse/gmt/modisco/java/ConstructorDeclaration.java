/**
 */
package org.eclipse.gmt.modisco.java;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Constructor Declaration</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.gmt.modisco.java.JavaPackage#getConstructorDeclaration()
 * @model
 * @generated
 */
public interface ConstructorDeclaration extends AbstractMethodDeclaration {
} // ConstructorDeclaration
