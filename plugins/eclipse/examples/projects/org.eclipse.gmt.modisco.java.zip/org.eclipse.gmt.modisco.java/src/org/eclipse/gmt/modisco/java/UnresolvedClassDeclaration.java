/**
 */

package org.eclipse.gmt.modisco.java;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Unresolved Class Declaration</b></em>'.
 * <!-- end-user-doc -->
 *
 * @model
 * @generated
 * @see org.eclipse.gmt.modisco.java.JavaPackage#getUnresolvedClassDeclaration()
 */
public interface UnresolvedClassDeclaration extends ClassDeclaration, UnresolvedItem {
} // UnresolvedClassDeclaration
