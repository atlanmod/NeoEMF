/**
 */
package org.eclipse.gmt.modisco.java;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Primitive Type Short</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.gmt.modisco.java.JavaPackage#getPrimitiveTypeShort()
 * @model
 * @generated
 */
public interface PrimitiveTypeShort extends PrimitiveType {
} // PrimitiveTypeShort
