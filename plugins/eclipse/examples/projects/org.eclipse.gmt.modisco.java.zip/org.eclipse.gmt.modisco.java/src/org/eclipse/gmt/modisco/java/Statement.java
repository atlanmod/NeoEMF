/**
 */

package org.eclipse.gmt.modisco.java;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Statement</b></em>'.
 * <!-- end-user-doc -->
 *
 * @model abstract="true"
 * @generated
 * @see org.eclipse.gmt.modisco.java.JavaPackage#getStatement()
 */
public interface Statement extends ASTNode {
} // Statement
