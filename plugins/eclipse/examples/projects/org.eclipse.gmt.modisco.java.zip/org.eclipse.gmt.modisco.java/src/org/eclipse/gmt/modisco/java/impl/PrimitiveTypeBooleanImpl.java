/**
 */

package org.eclipse.gmt.modisco.java.impl;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.gmt.modisco.java.JavaPackage;
import org.eclipse.gmt.modisco.java.PrimitiveTypeBoolean;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Primitive Type Boolean</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class PrimitiveTypeBooleanImpl extends PrimitiveTypeImpl implements PrimitiveTypeBoolean {

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    protected PrimitiveTypeBooleanImpl() {
        super();
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @generated
     */
    @Override
    protected EClass eStaticClass() {
        return JavaPackage.eINSTANCE.getPrimitiveTypeBoolean();
    }

} //PrimitiveTypeBooleanImpl
