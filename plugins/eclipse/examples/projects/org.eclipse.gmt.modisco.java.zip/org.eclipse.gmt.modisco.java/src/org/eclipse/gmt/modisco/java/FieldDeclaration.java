/**
 */
package org.eclipse.gmt.modisco.java;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Field Declaration</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.gmt.modisco.java.JavaPackage#getFieldDeclaration()
 * @model
 * @generated
 */
public interface FieldDeclaration extends BodyDeclaration, AbstractVariablesContainer {
} // FieldDeclaration
