/**
 */
package org.eclipse.gmt.modisco.java;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Namespace Access</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.gmt.modisco.java.JavaPackage#getNamespaceAccess()
 * @model abstract="true"
 * @generated
 */
public interface NamespaceAccess extends ASTNode {
} // NamespaceAccess
