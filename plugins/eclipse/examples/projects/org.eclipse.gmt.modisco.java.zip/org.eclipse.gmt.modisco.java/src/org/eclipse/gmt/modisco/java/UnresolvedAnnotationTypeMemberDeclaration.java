/**
 */
package org.eclipse.gmt.modisco.java;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Unresolved Annotation Type Member Declaration</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.gmt.modisco.java.JavaPackage#getUnresolvedAnnotationTypeMemberDeclaration()
 * @model
 * @generated
 */
public interface UnresolvedAnnotationTypeMemberDeclaration extends AnnotationTypeMemberDeclaration, UnresolvedItem {
} // UnresolvedAnnotationTypeMemberDeclaration
