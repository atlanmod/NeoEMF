/**
 */

package org.eclipse.gmt.modisco.java;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Unresolved Annotation Type Member Declaration</b></em>'.
 * <!-- end-user-doc -->
 *
 * @model
 * @generated
 * @see org.eclipse.gmt.modisco.java.JavaPackage#getUnresolvedAnnotationTypeMemberDeclaration()
 */
public interface UnresolvedAnnotationTypeMemberDeclaration extends AnnotationTypeMemberDeclaration, UnresolvedItem {
} // UnresolvedAnnotationTypeMemberDeclaration
