/**
 */

package org.eclipse.gmt.modisco.java;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Primitive Type Byte</b></em>'.
 * <!-- end-user-doc -->
 *
 * @model
 * @generated
 * @see org.eclipse.gmt.modisco.java.JavaPackage#getPrimitiveTypeByte()
 */
public interface PrimitiveTypeByte extends PrimitiveType {
} // PrimitiveTypeByte
