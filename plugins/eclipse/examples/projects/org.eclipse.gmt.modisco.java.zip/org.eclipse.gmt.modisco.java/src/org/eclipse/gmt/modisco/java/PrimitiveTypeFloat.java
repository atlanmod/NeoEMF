/**
 */
package org.eclipse.gmt.modisco.java;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Primitive Type Float</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.gmt.modisco.java.JavaPackage#getPrimitiveTypeFloat()
 * @model
 * @generated
 */
public interface PrimitiveTypeFloat extends PrimitiveType {
} // PrimitiveTypeFloat
