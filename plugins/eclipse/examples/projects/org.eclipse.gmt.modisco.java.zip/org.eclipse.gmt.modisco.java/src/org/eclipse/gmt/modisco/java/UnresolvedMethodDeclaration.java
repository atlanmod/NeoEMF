/**
 */
package org.eclipse.gmt.modisco.java;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Unresolved Method Declaration</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.gmt.modisco.java.JavaPackage#getUnresolvedMethodDeclaration()
 * @model
 * @generated
 */
public interface UnresolvedMethodDeclaration extends MethodDeclaration, UnresolvedItem {
} // UnresolvedMethodDeclaration
