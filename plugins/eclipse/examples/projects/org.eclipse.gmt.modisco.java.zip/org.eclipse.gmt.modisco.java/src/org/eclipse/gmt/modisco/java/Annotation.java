/**
 */

package org.eclipse.gmt.modisco.java;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Annotation</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 * <li>{@link org.eclipse.gmt.modisco.java.Annotation#getType <em>Type</em>}</li>
 * <li>{@link org.eclipse.gmt.modisco.java.Annotation#getValues <em>Values</em>}</li>
 * </ul>
 *
 * @model
 * @generated
 * @see org.eclipse.gmt.modisco.java.JavaPackage#getAnnotation()
 */
public interface Annotation extends Expression {

    /**
     * Returns the value of the '<em><b>Type</b></em>' containment reference.
     * <!-- begin-user-doc -->
     * <p>
     * If the meaning of the '<em>Type</em>' containment reference isn't clear,
     * there really should be more of a description here...
     * </p>
     * <!-- end-user-doc -->
     *
     * @return the value of the '<em>Type</em>' containment reference.
     *
     * @model containment="true" required="true" ordered="false"
     * @generated
     * @see #setType(TypeAccess)
     * @see org.eclipse.gmt.modisco.java.JavaPackage#getAnnotation_Type()
     */
    TypeAccess getType();

    /**
     * Sets the value of the '{@link org.eclipse.gmt.modisco.java.Annotation#getType <em>Type</em>}' containment
     * reference.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @param value the new value of the '<em>Type</em>' containment reference.
     *
     * @generated
     * @see #getType()
     */
    void setType(TypeAccess value);

    /**
     * Returns the value of the '<em><b>Values</b></em>' containment reference list.
     * The list contents are of type {@link org.eclipse.gmt.modisco.java.AnnotationMemberValuePair}.
     * <!-- begin-user-doc -->
     * <p>
     * If the meaning of the '<em>Values</em>' containment reference list isn't clear,
     * there really should be more of a description here...
     * </p>
     * <!-- end-user-doc -->
     *
     * @return the value of the '<em>Values</em>' containment reference list.
     *
     * @model containment="true"
     * @generated
     * @see org.eclipse.gmt.modisco.java.JavaPackage#getAnnotation_Values()
     */
    EList<AnnotationMemberValuePair> getValues();

} // Annotation
