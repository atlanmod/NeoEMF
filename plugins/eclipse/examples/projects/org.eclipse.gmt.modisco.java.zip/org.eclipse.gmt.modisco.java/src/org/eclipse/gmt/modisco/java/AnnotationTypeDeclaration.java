/**
 */

package org.eclipse.gmt.modisco.java;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Annotation Type Declaration</b></em>'.
 * <!-- end-user-doc -->
 *
 * @model
 * @generated
 * @see org.eclipse.gmt.modisco.java.JavaPackage#getAnnotationTypeDeclaration()
 */
public interface AnnotationTypeDeclaration extends AbstractTypeDeclaration {
} // AnnotationTypeDeclaration
