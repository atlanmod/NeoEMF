/**
 */

package org.eclipse.gmt.modisco.java;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Abstract Type Declaration</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 * <li>{@link org.eclipse.gmt.modisco.java.AbstractTypeDeclaration#getBodyDeclarations <em>Body Declarations</em>}</li>
 * <li>{@link org.eclipse.gmt.modisco.java.AbstractTypeDeclaration#getCommentsBeforeBody <em>Comments Before
 * Body</em>}</li>
 * <li>{@link org.eclipse.gmt.modisco.java.AbstractTypeDeclaration#getCommentsAfterBody <em>Comments After
 * Body</em>}</li>
 * <li>{@link org.eclipse.gmt.modisco.java.AbstractTypeDeclaration#getPackage <em>Package</em>}</li>
 * <li>{@link org.eclipse.gmt.modisco.java.AbstractTypeDeclaration#getSuperInterfaces <em>Super Interfaces</em>}</li>
 * </ul>
 *
 * @model abstract="true"
 * @generated
 * @see org.eclipse.gmt.modisco.java.JavaPackage#getAbstractTypeDeclaration()
 */
public interface AbstractTypeDeclaration extends BodyDeclaration, Type {

    /**
     * Returns the value of the '<em><b>Body Declarations</b></em>' containment reference list.
     * The list contents are of type {@link org.eclipse.gmt.modisco.java.BodyDeclaration}.
     * It is bidirectional and its opposite is '{@link org.eclipse.gmt.modisco.java.BodyDeclaration#getAbstractTypeDeclaration
     * <em>Abstract Type Declaration</em>}'.
     * <!-- begin-user-doc -->
     * <p>
     * If the meaning of the '<em>Body Declarations</em>' containment reference list isn't clear,
     * there really should be more of a description here...
     * </p>
     * <!-- end-user-doc -->
     *
     * @return the value of the '<em>Body Declarations</em>' containment reference list.
     *
     * @model opposite="abstractTypeDeclaration" containment="true"
     * @generated
     * @see org.eclipse.gmt.modisco.java.JavaPackage#getAbstractTypeDeclaration_BodyDeclarations()
     * @see org.eclipse.gmt.modisco.java.BodyDeclaration#getAbstractTypeDeclaration
     */
    EList<BodyDeclaration> getBodyDeclarations();

    /**
     * Returns the value of the '<em><b>Comments Before Body</b></em>' containment reference list.
     * The list contents are of type {@link org.eclipse.gmt.modisco.java.Comment}.
     * <!-- begin-user-doc -->
     * <p>
     * If the meaning of the '<em>Comments Before Body</em>' containment reference list isn't clear,
     * there really should be more of a description here...
     * </p>
     * <!-- end-user-doc -->
     *
     * @return the value of the '<em>Comments Before Body</em>' containment reference list.
     *
     * @model containment="true"
     * @generated
     * @see org.eclipse.gmt.modisco.java.JavaPackage#getAbstractTypeDeclaration_CommentsBeforeBody()
     */
    EList<Comment> getCommentsBeforeBody();

    /**
     * Returns the value of the '<em><b>Comments After Body</b></em>' containment reference list.
     * The list contents are of type {@link org.eclipse.gmt.modisco.java.Comment}.
     * <!-- begin-user-doc -->
     * <p>
     * If the meaning of the '<em>Comments After Body</em>' containment reference list isn't clear,
     * there really should be more of a description here...
     * </p>
     * <!-- end-user-doc -->
     *
     * @return the value of the '<em>Comments After Body</em>' containment reference list.
     *
     * @model containment="true"
     * @generated
     * @see org.eclipse.gmt.modisco.java.JavaPackage#getAbstractTypeDeclaration_CommentsAfterBody()
     */
    EList<Comment> getCommentsAfterBody();

    /**
     * Returns the value of the '<em><b>Package</b></em>' container reference.
     * It is bidirectional and its opposite is '{@link org.eclipse.gmt.modisco.java.Package#getOwnedElements <em>Owned
     * Elements</em>}'.
     * <!-- begin-user-doc -->
     * <p>
     * If the meaning of the '<em>Package</em>' container reference isn't clear,
     * there really should be more of a description here...
     * </p>
     * <!-- end-user-doc -->
     *
     * @return the value of the '<em>Package</em>' container reference.
     *
     * @model opposite="ownedElements" transient="false" ordered="false"
     * @generated
     * @see #setPackage(org.eclipse.gmt.modisco.java.Package)
     * @see org.eclipse.gmt.modisco.java.JavaPackage#getAbstractTypeDeclaration_Package()
     * @see org.eclipse.gmt.modisco.java.Package#getOwnedElements
     */
    org.eclipse.gmt.modisco.java.Package getPackage();

    /**
     * Sets the value of the '{@link org.eclipse.gmt.modisco.java.AbstractTypeDeclaration#getPackage <em>Package</em>}'
     * container reference.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     *
     * @param value the new value of the '<em>Package</em>' container reference.
     *
     * @generated
     * @see #getPackage()
     */
    void setPackage(org.eclipse.gmt.modisco.java.Package value);

    /**
     * Returns the value of the '<em><b>Super Interfaces</b></em>' containment reference list.
     * The list contents are of type {@link org.eclipse.gmt.modisco.java.TypeAccess}.
     * <!-- begin-user-doc -->
     * <p>
     * If the meaning of the '<em>Super Interfaces</em>' containment reference list isn't clear,
     * there really should be more of a description here...
     * </p>
     * <!-- end-user-doc -->
     *
     * @return the value of the '<em>Super Interfaces</em>' containment reference list.
     *
     * @model containment="true"
     * @generated
     * @see org.eclipse.gmt.modisco.java.JavaPackage#getAbstractTypeDeclaration_SuperInterfaces()
     */
    EList<TypeAccess> getSuperInterfaces();

} // AbstractTypeDeclaration
